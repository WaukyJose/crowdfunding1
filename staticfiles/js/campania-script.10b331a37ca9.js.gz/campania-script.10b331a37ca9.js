const procesarDonacion = (campania_id,monto) => {
    console.log("procesar donacion ", campania_id, monto)

    const body = {
        campania_id: campania_id,
        monto: monto
    }




}